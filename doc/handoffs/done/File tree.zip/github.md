repo: masshirodev/ai-session
branch: main
path: cmd/ai

## Last sync
date: 2026-09-27T15:36:59Z

### Updated in this project
- Recreated the `c` change-launch-folder box over the ghosted cockpit
- Three tree directions for the folder picker (1a, 1b, 1c)

## Screen map
| Screen | Repo files |
| --- | --- |
| Launch Folder Tree.dc.html · 0 (today) | cmd/ai/boxes.go (folderContent, promptField), cmd/ai/cockpit.go (View, modalView, board), cmd/ai/styles.go, cmd/ai/layout.go, cmd/ai/lineedit.go |
| Launch Folder Tree.dc.html · 1a–1c | cmd/ai/boxes.go, cmd/ai/wizard.go (picker panes, joinPanes pattern), cmd/ai/styles.go |
