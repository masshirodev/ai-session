repo: masshirodev/ai-session
branch: main
path: cmd/ai

## Last sync
date: 2026-09-29T19:20:30Z

### Updated in this project
- Rebuilt the gauge board at the 146 × 40 frame from design_test.go sample data
- Added three integrations-box shapes, an OpenUsage confirm step and a palette entry

## Screen map
| Screen | Repo files |
| --- | --- |
| 0a Board | cmd/ai/cockpit.go, cmd/ai/styles.go, cmd/ai/layout.go, cmd/ai/design_test.go |
| 1a / 1b / 1c Integrations box | cmd/ai/boxes.go (shareContent, joinPanes, formContent), cmd/ai/cockpit.go (modalView, sizing), doc/tui.md |
| 1d OpenUsage confirm | cmd/ai/boxes.go (installContent) |
| 1e Palette | cmd/ai/palette.go |
